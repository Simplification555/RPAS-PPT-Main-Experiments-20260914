#!/usr/bin/env bash
# Main homogeneous experiment launcher for one allocated node with exactly two
# A100s visible as CUDA devices 0 and 1. The caller must allocate the node.
set -euo pipefail

: "${RPAS_REPO_ROOT:?set RPAS_REPO_ROOT to the checked-out RPAS repository}"
REPO_ROOT="${RPAS_REPO_ROOT}"
MODEL_PATH="${RPAS_MODEL_PATH:-${HOME}/model/Qwen/Qwen3.5-9B}"
DATA_ROOT="${RPAS_MASBENCH_DATA_ROOT:-${REPO_ROOT}/data/masbench_aime_v1}"
OUTPUT_ROOT="${RPAS_OUTPUT_DIR:-${REPO_ROOT}/outputs/main_2gpu_9b}"
MAX_MODEL_LEN="${RPAS_MAX_MODEL_LEN:-16384}"
SERVER_MAX_NUM_SEQS="${RPAS_SERVER_MAX_NUM_SEQS:-16}"
MAX_NUM_BATCHED_TOKENS="${RPAS_MAX_NUM_BATCHED_TOKENS:-32768}"
MAX_TOKENS="${RPAS_MASBENCH_MAX_TOKENS:-6144}"
EVAL_CONCURRENCY="${RPAS_NATIVE_CONCURRENCY:-8}"
WORKERS_PER_GPU="${RPAS_WORKERS_PER_GPU:-2}"
BASE_PORT="${RPAS_BASE_PORT:-8004}"

if [[ "${CUDA_VISIBLE_DEVICES:-0,1}" != "0,1" && "${CUDA_VISIBLE_DEVICES:-0,1}" != "0,1,"* ]]; then
  echo "Refusing to run: CUDA_VISIBLE_DEVICES must expose only GPU 0 and 1, got '${CUDA_VISIBLE_DEVICES:-unset}'." >&2
  exit 2
fi

cd "${REPO_ROOT}"
mkdir -p "${OUTPUT_ROOT}" "${REPO_ROOT}/logs"
source "${REPO_ROOT}/scripts/preflight_main_2gpu.sh"
[[ -n "${QWEN_ENV:-}" ]] && export PATH="${QWEN_ENV}/bin:${PATH}"
[[ -n "${GEPA_ENV:-}" ]] && export PATH="${GEPA_ENV}/bin:${PATH}"
[[ -n "${QWEN_ENV:-}" && -d "${QWEN_ENV}/lib" ]] && export LD_LIBRARY_PATH="${QWEN_ENV}/lib:${LD_LIBRARY_PATH:-}"
export GEPA_QWEN_DISABLE_THINKING=1
export GEPA_PHASE2_PROMPT_MODE=deliberate
export GEPA_MAX_COMPLETION_TOKENS="${MAX_TOKENS}"
export RPAS_EXTERNAL_MODEL="Qwen/Qwen3.5-9B"
export RPAS_MASBENCH_MAX_TOKENS="${MAX_TOKENS}"
export RPAS_MAAS_EMBEDDING_MODEL="${RPAS_MAAS_EMBEDDING_MODEL:-${HOME}/model/sentence-transformers/all-MiniLM-L6-v2}"

nvidia-smi -i 0,1

PIDS=()
cleanup() {
  set +e
  for pid in "${PIDS[@]:-}"; do kill "${pid}" 2>/dev/null || true; done
  wait 2>/dev/null || true
}
trap cleanup EXIT INT TERM

start_server() {
  local gpu="$1" port="$2" log="${REPO_ROOT}/logs/main-9b-gpu${1}.log"
  CUDA_VISIBLE_DEVICES="${gpu}" "${VLLM_BIN}" serve "${MODEL_PATH}" \
    --served-model-name "Qwen/Qwen3.5-9B" --host 127.0.0.1 --port "${port}" \
    --tensor-parallel-size 1 --max-model-len "${MAX_MODEL_LEN}" \
    --max-num-seqs "${SERVER_MAX_NUM_SEQS}" \
    --max-num-batched-tokens "${MAX_NUM_BATCHED_TOKENS}" \
    --gpu-memory-utilization "${RPAS_GPU_MEMORY_UTILIZATION:-0.95}" \
    --enable-prefix-caching \
    --reasoning-parser qwen3 --language-model-only >"${log}" 2>&1 &
  PIDS+=("$!")
}

wait_ready() {
  local port="$1" pid="$2"
  for _ in $(seq 1 240); do
    if curl -sf "http://127.0.0.1:${port}/health" >/dev/null; then return 0; fi
    if ! kill -0 "${pid}" 2>/dev/null; then return 1; fi
    sleep 5
  done
  return 1
}

start_server 0 "${BASE_PORT}"
start_server 1 "$((BASE_PORT + 1))"
if ! wait_ready "${BASE_PORT}" "${PIDS[0]}"; then
  tail -n 240 "${REPO_ROOT}/logs/main-9b-gpu0.log" >&2 || true
  exit 1
fi
if ! wait_ready "$((BASE_PORT + 1))" "${PIDS[1]}"; then
  tail -n 240 "${REPO_ROOT}/logs/main-9b-gpu1.log" >&2 || true
  exit 1
fi

QUEUE_FILE="${REPO_ROOT}/logs/main-2gpu-queue.$$.tsv"
QUEUE_LOCK="${QUEUE_FILE}.lock"
JOB_LOG_DIR="${REPO_ROOT}/logs/main-2gpu-workers.$$.d"
mkdir -p "${JOB_LOG_DIR}"
trap 'rm -f "${QUEUE_FILE}" "${QUEUE_LOCK}"; rm -rf "${JOB_LOG_DIR}"; cleanup' EXIT INT TERM

for method in rpas aflow maas; do
  for axis in breadth depth horizon parallel robustness; do
    printf '%s\t%s\n' "${method}" "${axis}" >>"${QUEUE_FILE}"
  done
done

run_one() {
  local gpu="$1" method="$2" axis="$3" port
  if [[ "${gpu}" == 0 ]]; then port="${BASE_PORT}"; else port="$((BASE_PORT + 1))"; fi
  export CUDA_VISIBLE_DEVICES="${gpu}"
  export RPAS_EXTERNAL_API_BASE="http://127.0.0.1:${port}/v1"
  export GEPA_QWEN35_9B_API_BASE="${RPAS_EXTERNAL_API_BASE}"
  export GEPA_QWEN35_9B_REMOTE_PROFILE_API_BASE="${RPAS_EXTERNAL_API_BASE}"
  export GEPA_QWEN35_9B_GPU4_API_BASE="${RPAS_EXTERNAL_API_BASE}"
  export GEPA_QWEN35_9B_GPU5_API_BASE="${RPAS_EXTERNAL_API_BASE}"
  export GEPA_QWEN35_9B_GPU6_API_BASE="${RPAS_EXTERNAL_API_BASE}"
  export GEPA_QWEN35_9B_GPU7_API_BASE="${RPAS_EXTERNAL_API_BASE}"
  local out="${OUTPUT_ROOT}/${method}/${axis}/seed_0"
  mkdir -p "${out}"
  echo "START gpu=${gpu} method=${method} axis=${axis} port=${port}"
  if [[ "${method}" == rpas ]]; then
    PYTHONPATH="${REPO_ROOT}" "${EXPERIMENT_PYTHON}" -u experiments/phase2_wan_agent_search.py \
      --config experiments/phase2_wan_agent_config_qwen35_9b_homogeneous.json \
      --dataset masbench --data-dir "${DATA_ROOT}" --masbench-data-dir "${DATA_ROOT}" \
      --masbench-axis "${axis}" --network-profile lan_homogeneous --mode wan_pareto \
      --search-size 24 --selection-size 24 --test-size 60 --data-seed 2026 \
      --seed-candidates 9 --new-candidate-budget 24 --selection-shortlist-size 8 \
      --eval-concurrency "${EVAL_CONCURRENCY}" --seed 0 --reflection-mode llm \
      --output-dir "${OUTPUT_ROOT}/rpas" >"${out}/run.log" 2>&1
  else
    PYTHONPATH="${REPO_ROOT}" "${EXPERIMENT_PYTHON}" -m external_comparison.runners.masbench_native \
      --method "${method}" --axis "${axis}" --seed 0 --limit 0 --output-dir "${out}" \
      >"${out}/run.log" 2>&1
  fi
  echo "DONE gpu=${gpu} method=${method} axis=${axis}"
}

worker() {
  local gpu="$1" wid="$2" method axis
  while :; do
    exec 9>"${QUEUE_LOCK}"
    flock 9
    if IFS=$'\t' read -r method axis <"${QUEUE_FILE}"; then
      sed -i '1d' "${QUEUE_FILE}"
    else
      method=""; axis=""
    fi
    flock -u 9
    exec 9>&-
    [[ -n "${method}" ]] || break
    run_one "${gpu}" "${method}" "${axis}" 2>&1 | tee "${JOB_LOG_DIR}/gpu${gpu}-worker${wid}-${method}-${axis}.log"
  done
}

for gpu in 0 1; do
  for wid in $(seq 1 "${WORKERS_PER_GPU}"); do
    worker "${gpu}" "${wid}" &
  done
done
wait
echo "MAIN 2-GPU MASBench queue completed."
