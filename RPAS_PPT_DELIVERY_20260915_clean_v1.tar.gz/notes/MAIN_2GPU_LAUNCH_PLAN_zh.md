# 两张 A100 主实验启动方案

本入口只面向已经分配到同一节点、且在作业内可见为 `CUDA_VISIBLE_DEVICES=0,1` 的两张 A100。它不猜测分区名、不自动申请其他 GPU，也不会把旧 SCIR 地址当作新 CPFS 入口。

主表保持同质条件：三个方法都使用 Qwen3.5-9B、相同 prompt、解码、答案协议和冻结数据。PPT 中的 27B 不混入主表；Qwen3.5-27B/Qwen3.6-27B reflector 必须另开异构消融目录并单独报告。

默认吞吐设置：每张卡一个 9B vLLM replica，`max_num_seqs=8`；每张卡两个工作进程，每个 runner 并发 4，目标是每卡最多 8 个在途请求。默认 `max_model_len=16384`、`max_tokens=6144`，避免把旧的 2048 截断上限混入正式结果。

队列覆盖 RPAS、AFlow、MaAS 的五个 MASBench 轴；RPAS 使用 PPT 对齐的 `search=24 / select=24 / test=60`。AIME 已有合格结果，不重复消费；GAIA 必须先通过附件/工具 adapter smoke，不能用“只把附件路径传给模型”的旧实现冒充完整实验。

新机器的实际 SSH 命令、端口、认证方式和远端仓库目录仍需从用户提供的入口确定。`/mnt/cpfs/epic-user/niutianle-20260612/` 是目的路径，不是可登录地址。

上传后先做只读检查：

```bash
hostname
nvidia-smi -L
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES-}"
test "${CUDA_VISIBLE_DEVICES-}" = "0,1"
```

确认通过后运行：

```bash
RPAS_REPO_ROOT=/mnt/cpfs/epic-user/niutianle-20260612/RPAS \
  bash work/main_2gpu_max_throughput.sh
```
