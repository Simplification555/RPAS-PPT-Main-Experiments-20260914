# 两张 A100 主实验运行方案

## 1. 目标与冻结范围

本方案用于两张 A100 上的高速正式实验。AIME 主实验已经完成，本轮不重复消耗 AIME 搜索预算；正式补实验包括：

1. MasBench 五个轴：breadth、depth、horizon、parallel、robustness；
2. 三个方法：RPAS homogeneous v1.2、官方 AFlow、官方 MaAS；
3. GAIA 文件可见性实验：先完成文件/附件执行适配，再进行正式对比。

所有方法统一使用 Qwen3.5-9B，统一 temperature、top-p、最大生成长度和答案解析协议。并发只改变调度速度，不改变模型、数据、prompt、停止条件或候选选择规则。

## 2. MasBench 正式协议

### 2.1 数据与划分

- 数据源：Salesforce/MASBench，固定 revision `e85fc3e`，保留下载 SHA256。
- 每个轴单独运行，官方 train 只用于 search/select，官方 test 只用于最终 test。
- 每个轴固定为：`D_search=24`、`D_select=24`、`D_test=60`，`data_seed=2026`。
- search 和 select 在 official train 内无放回、按真实轴值分层；test 在 official test 内按真实轴值分层。
- 五个轴必须使用同一套 split manifest、相同 id、prompt 和 gold answer；禁止 test 参与 prompt、拓扑、阈值、停止条件或候选选择。
- 当前仓库的 `60/30/30` 仅作为旧实验记录，不作为 PPT 对齐后的正式 MasBench 结果。

### 2.2 方法与变量

- RPAS：9 个 seed candidates、24 个新候选、shortlist 上限 8；使用 WAN-GEPA Pareto 搜索和 LLM reflector。
- AFlow：使用官方 MCTS/workflow search；不把 AFlow 的搜索成本写成 0。
- MaAS：使用官方 controller/graph search；生成代码执行错误按官方 evaluator 计为失败。
- 执行模型：Qwen3.5-9B；temperature=0；top-p=1；关闭 thinking；`max_tokens=6144`。
- 统一答案协议：`FINAL ANSWER: ...`；horizon 的多答案用 `<<horizon>>`，完整序列 exact match 为主指标。
- 每次调用记录 prompt/completion/total tokens、calls、latency、finish reason、error、truncation 和解析状态。

### 2.3 主要指标

每个轴至少报告：

- 完整序列 accuracy；
- component accuracy；
- valid answer rate；
- error rate、protocol error rate、truncated/unextractable rate；
- search/select/test calls；
- prompt、completion、total tokens；
- wall time、GPU-hours 和吞吐。

无效候选门槛保持仓库现有协议：valid execution rate ≥99%、error calls ≤1%、unextractable ≤1%、truncated+unextractable ≤5%。

## 3. GAIA 正式设计

### 3.1 先解决口径问题

GAIA 不能只把附件路径字符串传给模型。当前 `phase2_wan_agent_search.py` 的 GAIA loader 在附件模式下只提供 `Attachment path`，没有文件读取、PDF/表格解析、图像输入或工具调用执行器。因此在 adapter 完成前，不提交“完整 GAIA”结果。

正式 GAIA 必须采用以下之一：

1. 文件可见模式：将允许的本地附件转换为规范化文本/表格内容，并把内容作为 evidence 注入 prompt；
2. 工具模式：实现受限的本地 `read_file`、PDF/text/table 提取和图像输入接口，所有工具调用写入 telemetry；禁止联网搜索，避免额外变量。

默认采用文件可见模式，先支持 txt、md、csv、json、pdf 和常见表格；图像任务单独标记为 multimodal extension，不混入文本主表。

### 3.2 GAIA 划分

- 数据源：GAIA validation，固定 snapshot/revision 和本地 SHA256；不使用 private test 的不可见标签。
- 内部冻结划分：`D_search=60`、`D_select=30`、`D_test=60`。
- 按 Level 1/2/3、是否有附件、附件类型分层；所有方法使用同一 manifest。
- `D_test` 只作为最终 held-out validation，论文中明确称为“GAIA validation local split”，不声称是官方 leaderboard test。
- GAIA 主表只纳入附件已正确暴露给模型的样本；附件缺失、解析失败或工具错误单独报告，不静默删除。

### 3.3 GAIA 评价

- 主指标：normalized exact match / official answer normalization；
- 分层指标：Level 1/2/3、no-attachment/text-attachment、answer type；
- 工具指标：tool calls、successful reads、tool errors、平均 evidence tokens、总 tokens；
- 每个方法保存 2–4 个成功/失败案例，标注是规划错误、证据读取错误、计算错误还是答案抽取错误。

## 4. 两张 A100 的最快安全调度

### 4.1 服务拓扑

- 每张 A100 启动一个 Qwen3.5-9B vLLM replica，`tensor_parallel_size=1`；不要在单卡上启动多个模型副本。
- 两个 replica 使用相同模型 revision、相同 tokenizer、相同 decoding 和相同 prompt 协议。
- 每个 replica 暴露一个本地 endpoint；客户端按照 GPU 负载把轴/方法任务分配到两个 endpoint。
- Tinker 路线只作为可替换 provider，固定 `reasoning_effort=False`；本地 A100 正式结果和 Tinker 结果分开标记，不混成同一模型结果。

### 4.2 并发阶梯

不要一开始把“五路 × 16 并发”硬塞进一张卡。采用一次性短 smoke 后升档：

| 档位 | 单卡 max_model_len | 单卡 max_num_seqs | 任务客户端总并发 | 用途 |
|---|---:|---:|---:|---|
| S0 | 16,384 | 8 | 8 | 1 题/方法/轴 smoke |
| S1 | 16,384 | 16 | 12–16 | 默认正式档 |
| S2 | 16,384 | 24 | 16–24 | A100 80G 且无 preemption/OOM 时启用 |

`max_num_seqs` 是单个 vLLM replica 的总活跃序列数，不是每个框架各自独占的并发数。每张卡最多同时挂 2–3 个逻辑任务，超出的请求进入同一服务队列。若是 A100 40G，固定使用 S0/S1，不启用 S2。

### 4.3 任务分配

正式 MasBench 的 15 个 method×axis 作业采用动态队列：

- GPU0 和 GPU1 各自一个共享 vLLM 服务；
- RPAS 五轴优先分布到两个 endpoint，保持每轴独立 output/cache 目录；
- AFlow/MaAS 五轴作业在 RPAS 轴完成或释放队列槽后立即补位；
- 不为每个 Slurm array element 重复加载一份模型；
- 每个客户端 `eval_concurrency=8` 起步，S1/S2 只提高服务总并发，不改变方法内部预算。

这种方式能并行五个逻辑任务，但不会误把五个任务当成五个独立 GPU 模型实例。

## 5. 执行顺序

1. 下载并冻结 MasBench、GAIA snapshot，生成 split manifests 和 SHA256。
2. 在两张 A100 各跑一次 S0 smoke：每个方法/轴 1 个样本；GAIA 额外覆盖无附件、文本附件和 PDF 各 1 个样本。
3. 验证模型输出协议、附件解析、telemetry、断点续跑和 shared evaluation cache。
4. 先升到 S1；连续 100 个请求无 OOM、无异常 preemption、错误率为 0 后，才升 S2。
5. MasBench 五轴正式搜索/选择/测试与 AFlow/MaAS native 作业进入动态队列。
6. GAIA 先完成 adapter smoke，再进入正式 search/select/test；adapter 未通过时只报告 blocker，不生成伪正式结果。
7. 所有任务完成后统一运行 manifest、id、split leakage、token、accuracy 和 error-rate 审计，再生成总表。

## 6. 速度与可复现性边界

- 最大吞吐来自共享模型 replica、continuous batching 和两卡动态队列，而不是复制多个模型进程。
- 不通过缩短 `max_tokens`、删掉长题、改变 test split 或关闭失败样本来换吞吐。
- 评测并发可以增加；候选预算、数据划分、temperature、top-p、答案解析和质量门槛不能因速度改变。
- 每个 job 必须支持 resume；中断只从 checkpoint 继续，禁止重复计费/重复统计而不标注。
- 最终报告分开列出：模型推理吞吐、方法 search wall time、端到端 wall time、GPU-hours 和 total tokens。

## 7. 当前启动前阻塞项

- [ ] GAIA 文件/附件 adapter 完成并通过 smoke；
- [ ] GAIA snapshot、revision、SHA256 和分层 manifest 冻结；
- [ ] MasBench 从旧 `60/30/30` 重新生成 PPT 对齐的 `24/24/60` manifest；
- [ ] 两张 A100 的显存型号确认（40G 或 80G）；
- [ ] S0/S1 benchmark 确定单卡可用 `max_num_seqs`；
- [ ] Tinker 与本地 A100 的 provider 标识、计费和结果目录分开。

