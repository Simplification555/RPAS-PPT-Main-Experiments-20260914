from collections import Counter
from pathlib import Path

import pyarrow.parquet as pq


base = Path.home() / "RPAS/data/masbench"
for axis in ("breadth", "depth", "horizon", "parallel", "robustness"):
    print("===", axis)
    for split in ("train", "test"):
        path = base / axis / f"{split}-00000-of-00001.parquet"
        table = pq.read_table(path)
        print(split, table.num_rows, table.column_names)
        values = Counter(map(str, table.column("value").to_pylist()))
        print("value", dict(sorted(values.items())))
        for name in ("reward_model_json", "extra_info_json", "prompt_json", "data"):
            if name in table.column_names:
                value = table.column(name)[0].as_py()
                preview = str(value)[:180].replace("\n", " ")
                print(name, type(value).__name__, preview)
