"""Validate and aggregate the frozen MASBench native comparison outputs."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


AXES = ("breadth", "depth", "horizon", "parallel", "robustness")
METHODS = ("aflow", "maas")


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def rpas_run_dir(root: Path, axis: str) -> Path:
    return root / "masbench" / f"{axis}_official_test" / "lan_homogeneous" / "wan_pareto" / "seed_0"


def rpas_row(result: dict, run_dir: Path, expected: list[dict], method: str, axis: str) -> tuple[dict, list[dict]]:
    selected = [row for row in result.get("selected_test_rows", []) if int(row.get("selected_rank", 0)) == 0]
    if not selected:
        raise ValueError("RPAS result has no selected rank-0 test row")
    test = selected[0].get("test", {})
    candidate_id = selected[0].get("candidate_id", "")
    output_path = run_dir / f"test_outputs_{candidate_id}.json"
    outputs = json.loads(output_path.read_text(encoding="utf-8")) if output_path.exists() else []
    expected_ids = [row["id"] for row in expected]
    actual_ids = [row.get("example_id", row.get("id")) for row in outputs]
    if actual_ids != expected_ids:
        raise ValueError("RPAS test output ids/count do not match frozen test split")
    n = len(outputs)
    return {
        "method": method,
        "axis": axis,
        "n": n,
        "score": test.get("score"),
        "component_score": test.get("component_score"),
        "valid_answer_rate": test.get("valid_answer_rate"),
        "calls": round(float(test.get("avg_calls", 0.0)) * n),
        "total_tokens": round(float(test.get("avg_total_tokens", 0.0)) * n),
        "errors": round(float(test.get("avg_errors", 0.0)) * n),
        "model": (result.get("model_manifest") or {}).get("qwen35_9b", {}).get("litellm_model", "Qwen/Qwen3.5-9B"),
        "decoding": (result.get("model_manifest") or {}).get("qwen35_9b", {}).get("completion_kwargs", {}),
        "official_commit": result.get("git_commit"),
    }, outputs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--split-root", type=Path, default=Path("data/masbench_aime_v1"))
    parser.add_argument("--rpas-root", type=Path, help="RPAS phase-2 output root; adds the third method to the report.")
    args = parser.parse_args()
    rows: list[dict] = []
    missing: list[str] = []
    invalid: list[str] = []
    methods = METHODS + (("rpas",) if args.rpas_root else ())
    for method in methods:
        for axis in AXES:
            run_dir = rpas_run_dir(args.rpas_root, axis) if method == "rpas" else args.root / method / axis / "seed_0"
            result_path = run_dir / "result.json"
            if not result_path.exists():
                missing.append(f"{method}/{axis}")
                continue
            result = json.loads(result_path.read_text(encoding="utf-8"))
            test_path = run_dir / "test_outputs.jsonl"
            expected = read_jsonl(args.split_root / axis / "test.jsonl")
            if method == "rpas":
                try:
                    row, outputs = rpas_row(result, run_dir, expected, method, axis)
                except (KeyError, TypeError, ValueError) as exc:
                    invalid.append(f"{method}/{axis}:{exc}")
                    continue
                rows.append(row)
                continue
            outputs = read_jsonl(test_path) if test_path.exists() else []
            expected_ids = [row["id"] for row in expected]
            actual_ids = [row.get("id") for row in outputs]
            if actual_ids != expected_ids:
                invalid.append(f"{method}/{axis}:test_ids_or_count")
            summary = result.get("summary", {})
            rows.append({
                "method": method,
                "axis": axis,
                "n": len(outputs),
                "score": summary.get("score"),
                "component_score": summary.get("component_score"),
                "valid_answer_rate": summary.get("valid_answer_rate"),
                "calls": summary.get("calls"),
                "total_tokens": summary.get("total_tokens"),
                "errors": summary.get("errors"),
                "model": result.get("model"),
                "decoding": result.get("decoding"),
                "official_commit": result.get("official_commit"),
            })
    report = {"root": str(args.root), "rpas_root": str(args.rpas_root) if args.rpas_root else "", "expected_runs": len(methods) * len(AXES), "runs": rows, "missing": missing, "invalid": invalid, "complete": not missing and not invalid}
    args.root.mkdir(parents=True, exist_ok=True)
    (args.root / "aggregate.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (args.root / "aggregate.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = ["method", "axis", "n", "score", "component_score", "valid_answer_rate", "calls", "total_tokens", "errors", "model", "decoding", "official_commit"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
