"""Run the official AFlow/MaAS MATH workflows on the frozen MASBench test view.

This runner deliberately evaluates only the frozen test JSONL.  The native
workflows keep their own published controller/workflow; their realized model
calls and tokens are recorded instead of pretending they used RPAS's search
budget.
"""

from __future__ import annotations

import argparse
import asyncio
import importlib
import json
import multiprocessing
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Callable

from external_comparison.adapters.native_common import call_record, env_path, git_commit
from phase2_wan_agent_search import (
    MASBENCH_ANSWER_SEPARATOR,
    extract_final_answer,
    extract_masbench_final_answer,
    extract_prediction_for_dataset,
    score_answer_components,
    score_example_answer,
)


def _maas_run_code_worker(conn, source: str) -> None:
    """Spawn-safe copy of MaAS's run_code, without importing DashScope."""
    try:
        global_namespace = {}
        disallowed_imports = [
            "os", "sys", "subprocess", "multiprocessing",
            "matplotlib", "seaborn", "plotly", "bokeh", "ggplot",
            "pylab", "tkinter", "PyQt5", "wx", "pyglet",
        ]
        for lib in disallowed_imports:
            if f"import {lib}" in source or f"from {lib}" in source:
                conn.send(("Error", f"Prohibited import: {lib} and graphing functionalities"))
                return
        exec(source, global_namespace)
        if "solve" in global_namespace and callable(global_namespace["solve"]):
            conn.send(("Success", str(global_namespace["solve"]())))
        else:
            conn.send(("Error", "Function 'solve' not found"))
    except BaseException as exc:  # pragma: no cover - child safety net
        details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        conn.send(("Error", f"Execution error: {exc}\n{details}"))
    finally:
        conn.close()


def _load_rows(path: Path, limit: int = 0) -> list[dict[str, Any]]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows:
        raise ValueError(f"empty MASBench split: {path}")
    return rows[:limit] if limit > 0 else rows


def _config():
    from scripts.async_llm import LLMConfig

    return LLMConfig(
        {
            "model": os.environ.get("RPAS_EXTERNAL_MODEL", "Qwen/Qwen3.5-9B"),
            "key": os.environ.get("RPAS_EXTERNAL_API_KEY", "EMPTY"),
            "base_url": os.environ.get("RPAS_EXTERNAL_API_BASE", "http://127.0.0.1:29500/v1"),
            "temperature": 0.0,
            "top_p": 1.0,
        }
    )


def _decoding_manifest() -> dict[str, Any]:
    return {
        "temperature": 0.0,
        "top_p": 1.0,
        "max_tokens": int(os.environ.get("RPAS_MASBENCH_MAX_TOKENS", "6144")),
        "enable_thinking": False,
    }


def _limit_aflow_tokens(llm) -> None:
    original_create = llm.aclient.chat.completions.create
    max_tokens = int(os.environ.get("RPAS_MASBENCH_MAX_TOKENS", "6144"))

    async def create(*args, **kwargs):
        kwargs.setdefault("max_tokens", max_tokens)
        kwargs.setdefault("extra_body", {"chat_template_kwargs": {"enable_thinking": False}})
        return await original_create(*args, **kwargs)

    llm.aclient.chat.completions.create = create


def _canonical_scoring_output(output: str, answer: str) -> tuple[str, bool]:
    """Adapt native answer formatting without changing the native output."""

    if extract_masbench_final_answer(output):
        return output, False
    # AFlow/MaAS MATH workflows sometimes return a natural-language solution
    # with the final scalar answer but no RPAS marker.  The score-only wrapper
    # makes this a protocol adaptation, not a change to the native workflow.
    if MASBENCH_ANSWER_SEPARATOR not in str(answer):
        fallback = extract_final_answer(output)
        if fallback:
            return f"{output}\nFINAL ANSWER: {fallback}", True
    return output, False


def _result_row(row: dict[str, Any], output: str) -> dict[str, Any]:
    scoring_output, used_fallback = _canonical_scoring_output(output, str(row["answer"]))
    prediction = extract_prediction_for_dataset(scoring_output, "masbench")
    return {
        "id": row["id"],
        "answer": row["answer"],
        "prediction": prediction,
        "score": score_example_answer(scoring_output, row["answer"], "masbench"),
        "component_score": score_answer_components(scoring_output, row["answer"], "masbench"),
        "answer_protocol_valid": bool(prediction),
        "axis": row.get("axis", ""),
        "axis_value": row.get("axis_value", ""),
        "official_split": row.get("official_split", "test"),
        "output": output,
        "scoring_protocol_fallback": used_fallback,
    }


def _install_maas_code_timeout() -> int:
    """Keep native MaAS code execution from holding a whole SLURM task forever.

    The published Programmer uses a ProcessPoolExecutor context manager.  When
    generated code hangs, its timeout path can still wait for the executor
    during context-manager teardown.  This narrow patch keeps the official
    workflow/operators, but uses a killable child process and records the
    timeout in the run manifest.
    """
    timeout_seconds = int(os.environ.get("RPAS_MAAS_CODE_TIMEOUT_SECONDS", "90"))
    from maas.ext.maas.scripts.optimized.MATH.test.template import operator as operator_module

    programmer_class = operator_module.Programmer
    if getattr(programmer_class, "_rpas_timeout_installed", False):
        return timeout_seconds

    async def safe_exec_code(self, code, timeout=600):
        # MaAS has already initialized CUDA by the time Programmer is used;
        # forking at that point can deadlock before the child is visible.
        worker = r'''
import contextlib
import io
import json
import sys
import traceback

source = sys.argv[1]
namespace = {}
disallowed = [
    "os", "sys", "subprocess", "multiprocessing",
    "matplotlib", "seaborn", "plotly", "bokeh", "ggplot",
    "pylab", "tkinter", "PyQt5", "wx", "pyglet",
]
try:
    for lib in disallowed:
        if f"import {lib}" in source or f"from {lib}" in source:
            result = ("Error", f"Prohibited import: {lib} and graphing functionalities")
            break
    else:
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            exec(source, namespace)
            if "solve" in namespace and callable(namespace["solve"]):
                result = ("Success", str(namespace["solve"]()))
            else:
                result = ("Error", "Function 'solve' not found")
except BaseException as exc:
    details = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    result = ("Error", f"Execution error: {exc}\n{details}")
print(json.dumps(result, ensure_ascii=True))
'''
        process = await asyncio.create_subprocess_exec(
            sys.executable, "-c", worker, code,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )         
        try:
            stdout, _ = await asyncio.wait_for(process.communicate(), timeout_seconds)
            if process.returncode != 0:
                return "Error", f"Code execution exited with code {process.returncode}"
            try:
                return tuple(json.loads(stdout.decode("utf-8").strip().splitlines()[-1]))
            except Exception as exc:
                return "Error", f"Code execution returned invalid output: {exc}"
        except asyncio.TimeoutError:
            process.kill()
            await process.communicate()
            return "Error", f"Code execution timed out after {timeout_seconds}s"

    programmer_class.exec_code = safe_exec_code
    programmer_class._rpas_timeout_installed = True
    return timeout_seconds


def _write_outputs(output_dir: Path, manifest: dict[str, Any], rows: list[dict[str, Any]], calls: list[dict[str, Any]]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (output_dir / "test_outputs.jsonl").open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    with (output_dir / "calls.jsonl").open("w", encoding="utf-8") as handle:
        for row in calls:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    summary = {
        "method": manifest["method"],
        "dataset": "masbench",
        "axis": manifest["axis"],
        "split": "test",
        "num_examples": len(rows),
        "score": sum(float(row["score"]) for row in rows) / len(rows) if rows else 0.0,
        "component_score": sum(float(row["component_score"]) for row in rows) / len(rows) if rows else 0.0,
        "valid_answer_rate": sum(bool(row["answer_protocol_valid"]) for row in rows) / len(rows) if rows else 0.0,
        "calls": len(calls),
        "total_tokens": sum(int(row.get("total_tokens", 0)) for row in calls),
        "errors": sum(bool(row.get("error")) for row in calls),
    }
    (output_dir / "result.json").write_text(json.dumps({**manifest, "summary": summary}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


async def _run_aflow(rows: list[dict[str, Any]], output_dir: Path, axis: str, seed: int) -> None:
    root = env_path("RPAS_AFLOW_ROOT", "/home/jianbaizhao/external_baselines/AFlow")
    if not root.exists():
        raise FileNotFoundError(root)
    os.chdir(root)
    sys.path.insert(0, str(root))
    workflow_class = importlib.import_module("workspace.MATH.workflows.round_1.graph").Workflow
    config = _config()
    calls: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    for row in rows:
        workflow = workflow_class("native_external", config, "MATH")
        _limit_aflow_tokens(workflow.llm)
        started = time.perf_counter()
        output, _ = await workflow(row["input"])
        elapsed = (time.perf_counter() - started) * 1000
        history = workflow.llm.get_usage_summary().get("history", [])
        for index, usage in enumerate(history):
            usage = dict(usage)
            usage["latency_ms"] = elapsed / max(1, len(history))
            calls.append(call_record(f"masbench-{axis}-aflow-seed-{seed}", "aflow", "masbench", "test", row["id"], index, usage))
        results.append(_result_row(row, str(output)))
    manifest = {
        "run_id": f"masbench-{axis}-aflow-seed-{seed}",
        "method": "aflow",
        "dataset": "masbench",
        "axis": axis,
        "seed": seed,
        "split": "test",
        "implementation_status": "official_mathy_workflow_artifact",
        "native_search": "official_fixed_MATH_workflow",
        "official_repo": str(root),
        "official_commit": git_commit(root),
        "model": config.model,
        "api_base": config.base_url,
        "decoding": _decoding_manifest(),
        "search_select_not_executed": True,
    }
    _write_outputs(output_dir, manifest, results, calls)


async def _run_maas(rows: list[dict[str, Any]], output_dir: Path, axis: str, seed: int) -> None:
    from external_comparison.adapters.native_maas import (
        _capture_usage,
        _install_import_compat,
        _llm_config,
        _patch_local_embedding_model,
        _prepare_runtime_config,
        _root,
    )

    root = _root()
    if not root.exists():
        raise FileNotFoundError(root)
    _prepare_runtime_config(output_dir)
    os.chdir(root)
    sys.path.insert(0, str(root))
    embedding_model = _patch_local_embedding_model()
    _install_import_compat(root)
    import torch

    from maas.ext.maas.models import controller as controller_module
    import maas.provider.openai_api  # noqa: F401

    # vLLM's Qwen3 reasoning parser may return a message with
    # ``content=None`` and the generated text in ``reasoning_content``.
    # MaAS's official OpenAI provider predates that response shape and
    # reads only ``message.content``.  Keep the native provider/workflow,
    # but make this narrow compatibility fallback so a valid generation is
    # not converted into a Pydantic ``None`` field.
    from maas.provider.openai_api import OpenAILLM

    original_cons_kwargs = OpenAILLM._cons_kwargs

    def _consistent_cons_kwargs(self, messages, timeout=None, **extra_kwargs):
        kwargs = original_cons_kwargs(self, messages, timeout=timeout, **extra_kwargs)
        template_kwargs = dict((kwargs.get("extra_body") or {}).get("chat_template_kwargs") or {})
        template_kwargs["enable_thinking"] = False
        kwargs["extra_body"] = {"chat_template_kwargs": template_kwargs}
        return kwargs

    OpenAILLM._cons_kwargs = _consistent_cons_kwargs

    def _qwen_reasoning_compatible_text(self, response):
        if not response.choices:
            return ""
        message = response.choices[0].message
        content = getattr(message, "content", None)
        if content is not None:
            return content
        reasoning = getattr(message, "reasoning_content", None)
        if reasoning is None:
            extras = getattr(message, "model_extra", None) or {}
            reasoning = extras.get("reasoning_content")
        return reasoning or ""

    OpenAILLM.get_choice_text = _qwen_reasoning_compatible_text
    maas_code_timeout_seconds = _install_maas_code_timeout()
    from maas.ext.maas.scripts.optimized.MATH.test.template.operator_registry import operator_names

    workflow_class = importlib.import_module("maas.ext.maas.scripts.optimized.MATH.test.graph").Workflow
    torch.manual_seed(seed)
    controller = controller_module.MultiLayerController(device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
    encoded_names = controller_module.sentence_encoder.model.encode(operator_names)
    embeddings = torch.as_tensor(encoded_names, dtype=torch.float32)
    if tuple(embeddings.shape) != (len(operator_names), 384):
        raise ValueError(f"unexpected MaAS operator embedding shape: {tuple(embeddings.shape)}")
    calls: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    row_timeout_seconds = int(os.environ.get("RPAS_MAAS_ROW_TIMEOUT_SECONDS", "300"))
    for row in rows:
        workflow = workflow_class("native_external", _llm_config(), "MATH", controller, embeddings)
        usage_records: list[dict[str, Any]] = []
        _capture_usage(workflow.llm, usage_records)
        started = time.perf_counter()
        try:
            output, _, _ = await asyncio.wait_for(
                workflow(row["input"]), timeout=row_timeout_seconds
            )
            error = None
        except Exception as exc:
            output = ""
            error = f"{type(exc).__name__}: {exc}"
        elapsed = (time.perf_counter() - started) * 1000
        for index, usage in enumerate(usage_records):
            usage = dict(usage)
            usage["model"] = _llm_config().model
            usage["latency_ms"] = elapsed / max(1, len(usage_records))
            calls.append(call_record(f"masbench-{axis}-maas-seed-{seed}", "maas", "masbench", "test", row["id"], index, usage))
        result = _result_row(row, str(output))
        if error:
            result["error"] = error
        results.append(result)
    config = _llm_config()
    manifest = {
        "run_id": f"masbench-{axis}-maas-seed-{seed}",
        "method": "maas",
        "dataset": "masbench",
        "axis": axis,
        "seed": seed,
        "split": "test",
        "implementation_status": "official_controller_and_MATH_workflow",
        "native_search": "official_controller_sampling",
        "official_repo": str(root),
        "official_commit": git_commit(root),
        "model": config.model,
        "api_base": config.base_url,
        "decoding": _decoding_manifest(),
        "embedding_model": embedding_model,
        "maas_code_timeout_seconds": maas_code_timeout_seconds,
        "maas_row_timeout_seconds": row_timeout_seconds,
        "search_select_not_executed": True,
    }
    _write_outputs(output_dir, manifest, results, calls)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", choices=("aflow", "maas"), required=True)
    parser.add_argument("--axis", choices=("breadth", "depth", "horizon", "parallel", "robustness"), required=True)
    parser.add_argument("--split-path", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()
    split_path = args.split_path or Path("data/masbench_aime_v1") / args.axis / "test.jsonl"
    rows = _load_rows(split_path, args.limit)
    runner: Callable[..., Any] = _run_aflow if args.method == "aflow" else _run_maas
    asyncio.run(runner(rows, args.output_dir, args.axis, args.seed))


if __name__ == "__main__":
    main()
