"""Materialize the controlled AIME-shaped MASBench split used by RPAS EC-1.

The official MASBench parquet files are kept immutable under ``data/masbench``.
This script creates a small, deterministic, value-balanced view for search,
select, and test.  Search/select use official train rows; test uses official
test rows only.  The raw official test remains available for a separate audit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

from phase2_wan_agent_search import (
    MASBENCH_AXES,
    masbench_row_to_example,
    read_masbench_split,
)


SOURCE_REVISION = "e85fc3e"
SOURCE_REPOSITORY = "Salesforce/MASBench"
DATA_SEED = 2026
SPLITS = ("search", "select", "test")
DEFAULT_SIZES = {"search": 60, "select": 30, "test": 30}

# ``value`` in the train parquet is a generation range, not the realized
# difficulty.  These fields are the axis values used for balancing.
TRAIN_VALUE_FIELDS = {
    "breadth": "breadth",
    "depth": "depth",
    "horizon": "num_problems",
    "parallel": "num_problems",
    "robustness": "num_total_problems",
}
TEST_VALUE_FIELDS = {
    "breadth": "actual_breadth",
    "depth": "depth",
    "horizon": "num_problems",
    "parallel": "num_problems",
    "robustness": "num_total_problems",
}


def _json_field(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if value is None:
        return {}
    try:
        parsed = json.loads(str(value))
    except (TypeError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _stable_id(axis: str, split: str, row: dict[str, Any], index: int) -> str:
    extra = _json_field(row.get("extra_info_json"))
    source_id = extra.get("example_id", extra.get("index", index))
    # Some official test shards restart ``example_id`` at zero for each
    # difficulty value.  Keep the row index in the canonical id so every
    # task remains uniquely addressable after the shards are pooled.
    return f"masbench:{axis}:{split}:{source_id}:row-{index}"


def _value_key(axis: str, official_split: str, row: dict[str, Any]) -> str:
    extra = _json_field(row.get("extra_info_json"))
    field = (TEST_VALUE_FIELDS if official_split == "test" else TRAIN_VALUE_FIELDS)[axis]
    value = extra.get(field)
    if value is None:
        value = row.get("value", "")
    return str(value)


def _sort_value(value: str) -> tuple[int, str]:
    try:
        return (0, f"{int(value):08d}")
    except ValueError:
        return (1, value)


def _row_key(seed: int, axis: str, official_split: str, row: dict[str, Any]) -> str:
    payload = f"{seed}:{axis}:{official_split}:{row['id']}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _usable_rows(axis: str, official_split: str, rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for index, row in enumerate(rows):
        example = masbench_row_to_example(row, axis, official_split, index)
        if example is None:
            continue
        example["source_example_id"] = example["id"]
        example["id"] = _stable_id(axis, official_split, row, index)
        example["axis_value"] = _value_key(axis, official_split, row)
        example["source_value"] = str(row.get("value", ""))
        result.append(example)
    return result


def _balanced_quotas(values: list[str], total: int) -> dict[str, int]:
    base, remainder = divmod(total, len(values))
    return {value: base + int(index < remainder) for index, value in enumerate(values)}


def _balanced_disjoint(
    pool: list[dict[str, Any]],
    *,
    axis: str,
    official_split: str,
    seed: int,
    first_size: int,
    second_size: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in pool:
        groups[str(row["axis_value"])].append(row)
    values = sorted(groups, key=_sort_value)
    first: list[dict[str, Any]] = []
    second: list[dict[str, Any]] = []
    first_quotas = _balanced_quotas(values, first_size)
    second_quotas = _balanced_quotas(values, second_size)
    for value in values:
        ordered = sorted(groups[value], key=lambda row: _row_key(seed, axis, official_split, row))
        required = first_quotas[value] + second_quotas[value]
        if required > len(ordered):
            raise ValueError(
                f"{axis}/{official_split} value={value} has {len(ordered)} rows, "
                f"but the controlled split needs {required}"
            )
        first.extend(ordered[: first_quotas[value]])
        second.extend(ordered[first_quotas[value] : required])
    first.sort(key=lambda row: _row_key(seed, axis, official_split, row))
    second.sort(key=lambda row: _row_key(seed + 1, axis, official_split, row))
    return first, second


def _balanced_sample(
    pool: list[dict[str, Any]],
    *,
    axis: str,
    official_split: str,
    seed: int,
    size: int,
) -> list[dict[str, Any]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in pool:
        groups[str(row["axis_value"])].append(row)
    values = sorted(groups, key=_sort_value)
    quotas = _balanced_quotas(values, size)
    selected: list[dict[str, Any]] = []
    for value in values:
        ordered = sorted(groups[value], key=lambda row: _row_key(seed, axis, official_split, row))
        if quotas[value] > len(ordered):
            raise ValueError(f"{axis}/{official_split} value={value} lacks rows for balanced sampling")
        selected.extend(ordered[: quotas[value]])
    selected.sort(key=lambda row: _row_key(seed + 1, axis, official_split, row))
    return selected


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_manifest(data_dir: Path, output_dir: Path, axes: list[str], sizes: dict[str, int], seed: int) -> dict[str, Any]:
    manifest: dict[str, Any] = {
        "schema_version": "rpas_ec1_masbench_aime_v1",
        "dataset": SOURCE_REPOSITORY,
        "source_revision": SOURCE_REVISION,
        "source_data_dir": str(data_dir.resolve()),
        "output_dir": str(output_dir.resolve()),
        "data_seed": seed,
        "split_sizes": sizes,
        "split_policy": "official_train_search_select_and_official_test_balanced_by_realized_axis_value",
        "aime_alignment": {
            "search": 60,
            "select": 30,
            "test": 30,
            "note": "Same task-count shape as RPAS AIME; MASBench official test remains available as an untouched audit view.",
        },
        "axes": {},
    }
    for axis in axes:
        train = _usable_rows(axis, "train", read_masbench_split(data_dir, axis, "train"))
        official_test = _usable_rows(axis, "test", read_masbench_split(data_dir, axis, "test"))
        search, select = _balanced_disjoint(
            train,
            axis=axis,
            official_split="train",
            seed=seed,
            first_size=sizes["search"],
            second_size=sizes["select"],
        )
        test = _balanced_sample(
            official_test,
            axis=axis,
            official_split="test",
            seed=seed,
            size=sizes["test"],
        )
        for split, rows in (("search", search), ("select", select), ("test", test)):
            _write_jsonl(output_dir / axis / f"{split}.jsonl", rows)
        manifest["axes"][axis] = {
            "train_usable": len(train),
            "official_test_usable": len(official_test),
            "train_value_field": TRAIN_VALUE_FIELDS[axis],
            "test_value_field": TEST_VALUE_FIELDS[axis],
            "train_values": dict(sorted(Counter(row["axis_value"] for row in train).items(), key=lambda item: _sort_value(item[0]))),
            "official_test_values": dict(sorted(Counter(row["axis_value"] for row in official_test).items(), key=lambda item: _sort_value(item[0]))),
            "search_values": dict(sorted(Counter(row["axis_value"] for row in search).items(), key=lambda item: _sort_value(item[0]))),
            "select_values": dict(sorted(Counter(row["axis_value"] for row in select).items(), key=lambda item: _sort_value(item[0]))),
            "test_values": dict(sorted(Counter(row["axis_value"] for row in test).items(), key=lambda item: _sort_value(item[0]))),
            "row_ids": {split: [row["id"] for row in rows] for split, rows in (("search", search), ("select", select), ("test", test))},
        }
    return manifest


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("data/masbench"))
    parser.add_argument("--output-dir", type=Path, default=Path("data/masbench_aime_v1"))
    parser.add_argument("--axes", nargs="+", choices=MASBENCH_AXES, default=list(MASBENCH_AXES))
    parser.add_argument("--seed", type=int, default=DATA_SEED)
    parser.add_argument("--search-size", type=int, default=DEFAULT_SIZES["search"])
    parser.add_argument("--select-size", type=int, default=DEFAULT_SIZES["select"])
    parser.add_argument("--test-size", type=int, default=DEFAULT_SIZES["test"])
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    sizes = {"search": args.search_size, "select": args.select_size, "test": args.test_size}
    manifest = build_manifest(args.data_dir, args.output_dir, args.axes, sizes, args.seed)
    for axis, payload in manifest["axes"].items():
        print(
            f"[MASBENCH-AIME] axis={axis} train={payload['train_usable']} "
            f"official_test={payload['official_test_usable']} "
            f"search={payload['search_values']} select={payload['select_values']} test={payload['test_values']}"
        )
    for path in sorted(args.data_dir.glob("**/*.parquet")):
        manifest.setdefault("source_files", {})[str(path.relative_to(args.data_dir))] = {
            "bytes": path.stat().st_size,
            "sha256": _sha256(path),
        }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = args.output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"[MASBENCH-AIME] wrote {manifest_path}")


if __name__ == "__main__":
    main()
