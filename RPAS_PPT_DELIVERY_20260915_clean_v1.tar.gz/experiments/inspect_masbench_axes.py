import json
from collections import Counter
from pathlib import Path

import pyarrow.parquet as pq


base = Path.home() / "RPAS/data/masbench"
for axis in ("breadth", "depth", "horizon", "parallel", "robustness"):
    print("===", axis)
    for split in ("train", "test"):
        table = pq.read_table(base / axis / f"{split}-00000-of-00001.parquet")
        counters = {}
        for raw in table.column("extra_info_json").to_pylist():
            payload = json.loads(raw)
            for key in ("breadth", "actual_breadth", "depth", "actual_depth", "num_problems", "longest_path", "num_igsm_problems", "num_niah_samples", "num_total_problems"):
                if key in payload:
                    value = payload[key]
                    if isinstance(value, list):
                        value = len(value)
                    counters.setdefault(key, Counter())[str(value)] += 1
        print(split, {key: dict(sorted(value.items())) for key, value in counters.items()})
