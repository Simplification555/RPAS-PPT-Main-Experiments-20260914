import json
from collections import Counter
from pathlib import Path

import pyarrow.parquet as pq


base = Path.home() / "RPAS/data/masbench"
for axis in ("breadth", "depth", "horizon", "parallel", "robustness"):
    print("===", axis)
    for split in ("train", "test"):
        table = pq.read_table(base / axis / f"{split}-00000-of-00001.parquet")
        keys = Counter()
        samples = []
        for raw in table.column("extra_info_json").to_pylist():
            payload = json.loads(raw)
            keys.update(payload.keys())
            if len(samples) < 3:
                samples.append(payload)
        print(split, "keys", sorted(keys))
        for sample in samples:
            print(json.dumps(sample, ensure_ascii=False, sort_keys=True)[:1000])
