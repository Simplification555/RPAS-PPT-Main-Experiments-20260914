#!/usr/bin/env python3
"""Audit a private GAIA PPT package before any experiment is launched."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


SPLITS = ("search", "select", "test")


def _sha256(value: str) -> str:
    return hashlib.sha256(" ".join(str(value).split()).encode()).hexdigest()


def _row_digest(row: dict[str, Any]) -> str:
    payload = {
        "task_id": row["task_id"],
        "level": row["level"],
        "question_sha256": row["question_sha256"],
        "answer_sha256": row["answer_sha256"],
        "attachment_relpath": row["attachment_relpath"],
        "attachment_sha256": row["attachment_sha256"],
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def audit(root: Path) -> dict[str, Any]:
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("privacy") != "private_only":
        raise ValueError("manifest privacy marker is not private_only")
    if manifest.get("public_upload_policy") != "manifests_only":
        raise ValueError("refusing a package without public_upload_policy=manifests_only")
    expected = manifest.get("targets", {})
    all_ids: set[str] = set()
    summaries: dict[str, Any] = {}
    for split in SPLITS:
        records_path = root / "records" / f"{split}.jsonl"
        manifest_path = root / "manifests" / f"{split}.jsonl"
        records = _read_jsonl(records_path)
        public_rows = _read_jsonl(manifest_path)
        if len(records) != int(expected[split]) or len(public_rows) != int(expected[split]):
            raise ValueError(f"{split} count mismatch: records={len(records)}, manifest={len(public_rows)}, target={expected[split]}")
        public_by_id = {row["task_id"]: row for row in public_rows}
        if len(public_by_id) != len(public_rows):
            raise ValueError(f"duplicate task ids in {split} manifest")
        for row in records:
            task_id = row["task_id"]
            if task_id in all_ids:
                raise ValueError(f"split leakage: {task_id}")
            all_ids.add(task_id)
            if not row.get("question") or not row.get("final_answer"):
                raise ValueError(f"empty question/answer in {split}: {task_id}")
            if row["question_sha256"] != _sha256(row["question"]):
                raise ValueError(f"question hash mismatch: {task_id}")
            if row["answer_sha256"] != _sha256(row["final_answer"]):
                raise ValueError(f"answer hash mismatch: {task_id}")
            if row["row_sha256"] != _row_digest(row):
                raise ValueError(f"row hash mismatch: {task_id}")
            if row.get("has_attachment") and row.get("attachment_path") and not Path(row["attachment_path"]).is_file():
                raise FileNotFoundError(f"missing attachment: {task_id}: {row['attachment_path']}")
            public = public_by_id.get(task_id)
            if public is None or public.get("row_sha256") != row["row_sha256"]:
                raise ValueError(f"public/private manifest mismatch: {task_id}")
        summaries[split] = {
            "count": len(records),
            "levels": {str(level): sum(row["level"] == level for row in records) for level in (1, 2, 3)},
            "attachments": sum(bool(row.get("has_attachment")) for row in records),
        }
    return {
        "status": "PASS",
        "dataset": "gaia",
        "split_namespace": "gaia_local_test",
        "total_rows": len(all_ids),
        "splits": summaries,
        "checks": ["exact target counts", "disjoint task ids", "question/answer hashes", "row hashes", "attachment existence"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True)
    args = parser.parse_args()
    try:
        result = audit(Path(args.root).expanduser().resolve())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
