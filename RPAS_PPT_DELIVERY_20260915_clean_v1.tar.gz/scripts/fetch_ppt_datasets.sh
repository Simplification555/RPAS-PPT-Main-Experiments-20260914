#!/usr/bin/env bash
set -euo pipefail

: "${DATA_ROOT:?set DATA_ROOT to the private data directory}"
mkdir -p "$DATA_ROOT"

python - <<'PY'
import os
from huggingface_hub import snapshot_download

root = os.environ["DATA_ROOT"]
masbench = snapshot_download(
    repo_id="Salesforce/MASBench",
    repo_type="dataset",
    revision="e85fc3e60107c87b690f9cdc478bad375a243ed0",
    local_dir=os.path.join(root, "masbench"),
)
print(f"MASBench snapshot: {masbench}")

# GAIA is gated and must not be copied to a public repository. The caller must
# accept the official terms first; keep this snapshot on the private node.
if os.environ.get("FETCH_GAIA", "0") == "1":
    gaia = snapshot_download(
        repo_id="gaia-benchmark/GAIA",
        repo_type="dataset",
        revision=os.environ.get("GAIA_REVISION", "main"),
        local_dir=os.path.join(root, "gaia"),
    )
    print(f"GAIA private snapshot: {gaia}")
    print("Next: set GAIA_SOURCE_REVISION to the resolved commit and run scripts/build_gaia_ppt_dataset.py.")
else:
    print("GAIA skipped; set FETCH_GAIA=1 only after gated access is configured.")
PY
