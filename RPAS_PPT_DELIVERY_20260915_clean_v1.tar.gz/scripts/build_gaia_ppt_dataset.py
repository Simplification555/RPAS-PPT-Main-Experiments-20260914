#!/usr/bin/env python3
"""Build the private GAIA validation package used by the PPT experiment.

The public repository contains this builder and the split specification only.
The output of this script contains questions, answers, and local attachment
paths and MUST stay on an access-controlled machine.

The builder is intentionally fail-closed: it only accepts rows that can be
traced to the requested validation directory/field, requires a gold answer,
and refuses to silently continue when an attachment is missing.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable


SCHEMA_VERSION = "gaia_ppt_private_v1"
SPLITS = ("search", "select", "test")
DEFAULT_TARGETS = {"search": 60, "select": 30, "test": 60}
ATTACHMENT_SUFFIXES = {
    ".pdf": "pdf",
    ".png": "image",
    ".jpg": "image",
    ".jpeg": "image",
    ".webp": "image",
    ".gif": "image",
    ".bmp": "image",
    ".wav": "audio",
    ".mp3": "audio",
    ".flac": "audio",
    ".m4a": "audio",
    ".csv": "table",
    ".tsv": "table",
    ".xls": "spreadsheet",
    ".xlsx": "spreadsheet",
    ".json": "structured",
    ".jsonl": "structured",
    ".txt": "text",
    ".md": "text",
    ".zip": "archive",
}


def _pick(row: dict[str, Any], *names: str) -> Any:
    for name in names:
        if name in row and row[name] is not None:
            return row[name]
    return None


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _canonical_text(value: Any) -> str:
    return " ".join(_text(value).split())


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_json_records(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() == ".jsonl":
        rows: list[dict[str, Any]] = []
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number} is not a JSON object")
            rows.append(value)
        return rows
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, list):
        return [dict(row) for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        for key in ("data", "rows", "validation", "dev"):
            if isinstance(payload.get(key), list):
                return [dict(row) for row in payload[key] if isinstance(row, dict)]
    raise ValueError(f"Unsupported JSON metadata shape: {path}")


def _read_metadata(path: Path) -> list[dict[str, Any]]:
    if path.suffix.lower() in {".json", ".jsonl"}:
        return _read_json_records(path)
    if path.suffix.lower() == ".parquet":
        try:
            import pyarrow.parquet as parquet
        except ModuleNotFoundError as exc:
            raise RuntimeError(
                "Reading GAIA Parquet requires pyarrow; install the repository runtime before building."
            ) from exc
        return [dict(row) for row in parquet.read_table(path).to_pylist()]
    raise ValueError(f"Unsupported metadata file: {path}")


def _metadata_candidates(snapshot_root: Path, source_split: str) -> list[Path]:
    accepted_names = {"metadata.json", "metadata.jsonl", "metadata.parquet"}
    candidates = []
    for path in sorted(snapshot_root.rglob("*")):
        if not path.is_file() or path.name.lower() not in accepted_names:
            continue
        normalized = path.as_posix().lower()
        if source_split.lower() in normalized:
            candidates.append(path)
    if candidates:
        return candidates

    # Some local mirrors flatten the snapshot.  Allow this only if rows carry
    # an explicit split field; rows without one are rejected below.
    flattened = [
        path
        for path in sorted(snapshot_root.glob("metadata.*"))
        if path.is_file() and path.suffix.lower() in {".json", ".jsonl", ".parquet"}
    ]
    if flattened:
        return flattened
    raise FileNotFoundError(
        f"No GAIA metadata file found below {snapshot_root}; expected a {source_split} snapshot."
    )


def _row_split(row: dict[str, Any]) -> str:
    return _canonical_text(_pick(row, "split", "Split", "subset", "Subset")).lower()


def _belongs_to_source_split(row: dict[str, Any], metadata_path: Path, source_split: str) -> bool:
    value = _row_split(row)
    if value:
        aliases = {source_split.lower()}
        if source_split.lower() == "validation":
            aliases.update({"dev", "public", "validation"})
        return value in aliases
    return source_split.lower() in metadata_path.as_posix().lower()


def _level(row: dict[str, Any], path: Path) -> int:
    raw = _pick(row, "Level", "level")
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid GAIA level in {path}: {raw!r}") from exc
    if value not in {1, 2, 3}:
        raise ValueError(f"GAIA level must be 1, 2, or 3 in {path}: {value}")
    return value


def _attachment_candidates(snapshot_root: Path, metadata_path: Path, raw_path: str) -> list[Path]:
    path = Path(raw_path)
    candidates = []
    if path.is_absolute():
        candidates.append(path)
    candidates.extend(
        [
            snapshot_root / path,
            metadata_path.parent / path,
            metadata_path.parent / path.name,
            snapshot_root / path.name,
        ]
    )
    seen: set[Path] = set()
    result = []
    for candidate in candidates:
        resolved = candidate.expanduser().resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        result.append(resolved)
    return result


def _resolve_attachment(snapshot_root: Path, metadata_path: Path, raw_path: str) -> Path | None:
    for candidate in _attachment_candidates(snapshot_root, metadata_path, raw_path):
        if candidate.is_file():
            return candidate
    return None


def _attachment_type(raw_path: str) -> str:
    return ATTACHMENT_SUFFIXES.get(Path(raw_path).suffix.lower(), "other") if raw_path else "none"


def _normalise_source_path(snapshot_root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(snapshot_root.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def _row_digest(record: dict[str, Any]) -> str:
    payload = {
        "task_id": record["task_id"],
        "level": record["level"],
        "question_sha256": record["question_sha256"],
        "answer_sha256": record["answer_sha256"],
        "attachment_relpath": record["attachment_relpath"],
        "attachment_sha256": record["attachment_sha256"],
    }
    return _sha256_bytes(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode())


def _normalise_rows(
    snapshot_root: Path,
    metadata_paths: Iterable[Path],
    source_split: str,
    strict_attachments: bool,
) -> tuple[list[dict[str, Any]], dict[str, str]]:
    by_id: dict[str, dict[str, Any]] = {}
    metadata_hashes: dict[str, str] = {}
    for metadata_path in metadata_paths:
        metadata_hashes[_normalise_source_path(snapshot_root, metadata_path)] = _sha256_file(metadata_path)
        for raw in _read_metadata(metadata_path):
            if not _belongs_to_source_split(raw, metadata_path, source_split):
                continue
            task_id = _text(_pick(raw, "task_id", "Task ID", "id"))
            question = _text(_pick(raw, "Question", "question", "prompt", "input"))
            answer = _text(_pick(raw, "Final answer", "final_answer", "answer"))
            if not task_id or not question or not answer:
                raise ValueError(
                    f"GAIA validation row is missing task_id/question/final answer in {metadata_path}: {raw.keys()}"
                )
            raw_attachment = _text(_pick(raw, "file_path", "file_name"))
            attachment = _resolve_attachment(snapshot_root, metadata_path, raw_attachment) if raw_attachment else None
            if raw_attachment and attachment is None and strict_attachments:
                raise FileNotFoundError(
                    f"Attachment for GAIA task {task_id} was not found: {raw_attachment!r} (metadata={metadata_path})"
                )
            attachment_relpath = _normalise_source_path(snapshot_root, attachment) if attachment else raw_attachment
            record = {
                "task_id": task_id,
                "question": question,
                "final_answer": answer,
                "level": _level(raw, metadata_path),
                "file_name": _text(_pick(raw, "file_name")),
                "file_path": raw_attachment,
                "attachment_relpath": attachment_relpath,
                "attachment_type": _attachment_type(raw_attachment),
                "has_attachment": bool(raw_attachment),
                "attachment_path": str(attachment) if attachment else "",
                "question_sha256": _sha256_bytes(_canonical_text(question).encode()),
                "answer_sha256": _sha256_bytes(_canonical_text(answer).encode()),
                "attachment_sha256": _sha256_file(attachment) if attachment else "",
                "source_metadata": _normalise_source_path(snapshot_root, metadata_path),
            }
            record["row_sha256"] = _row_digest(record)
            previous = by_id.get(task_id)
            if previous is not None:
                comparable = {key: previous[key] for key in ("question_sha256", "answer_sha256", "attachment_relpath", "level")}
                current = {key: record[key] for key in comparable}
                if comparable != current:
                    raise ValueError(f"Conflicting duplicate GAIA task_id: {task_id}")
                continue
            by_id[task_id] = record
    if not by_id:
        raise ValueError("No GAIA validation rows survived the fail-closed filters.")
    return list(by_id.values()), metadata_hashes


def _allocate_strata(strata: dict[tuple[int, str], list[dict[str, Any]]], targets: dict[str, int]) -> dict[tuple[tuple[int, str], str], int]:
    total = sum(len(rows) for rows in strata.values())
    target_total = sum(targets.values())
    if total < target_total:
        raise ValueError(f"GAIA validation has {total} usable rows, but the requested split needs {target_total}.")
    if not all(targets.get(split, 0) >= 0 for split in SPLITS):
        raise ValueError(f"Split targets must be non-negative: {targets}")

    allocation: dict[tuple[tuple[int, str], str], int] = {}
    remaining_by_stratum: dict[tuple[int, str], int] = {}
    remaining_by_split = {split: targets[split] for split in SPLITS}
    quotas: dict[tuple[tuple[int, str], str], float] = {}
    for key, rows in sorted(strata.items()):
        remaining_by_stratum[key] = len(rows)
        for split in SPLITS:
            quota = len(rows) * targets[split] / target_total
            quotas[(key, split)] = quota
            base = math.floor(quota)
            allocation[(key, split)] = base
            remaining_by_stratum[key] -= base
            remaining_by_split[split] -= base

    while sum(remaining_by_split.values()) > 0:
        candidates = [
            (quotas[(key, split)] - allocation[(key, split)], key, split)
            for key in sorted(strata)
            for split in SPLITS
            if remaining_by_stratum[key] > 0 and remaining_by_split[split] > 0
        ]
        if not candidates:
            raise AssertionError(f"Unable to complete stratified allocation: {remaining_by_split}")
        _, key, split = max(candidates, key=lambda item: (item[0], -item[1][0], item[1][1], item[2]))
        allocation[(key, split)] += 1
        remaining_by_stratum[key] -= 1
        remaining_by_split[split] -= 1
    if any(value != 0 for value in remaining_by_split.values()):
        raise AssertionError(f"Split allocation mismatch: {remaining_by_split}")
    return allocation


def _stratified_split(rows: list[dict[str, Any]], targets: dict[str, int], seed: int) -> dict[str, list[dict[str, Any]]]:
    strata: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        strata[(int(row["level"]), str(row["attachment_type"]))].append(row)
    allocation = _allocate_strata(strata, targets)
    rng = random.Random(seed)
    output = {split: [] for split in SPLITS}
    for key in sorted(strata):
        group = sorted(strata[key], key=lambda row: row["task_id"])
        rng.shuffle(group)
        cursor = 0
        for split in SPLITS:
            count = allocation[(key, split)]
            output[split].extend(group[cursor : cursor + count])
            cursor += count
    for split in SPLITS:
        if len(output[split]) != targets[split]:
            raise AssertionError(f"{split} expected {targets[split]} rows, got {len(output[split])}")
        output[split].sort(key=lambda row: row["task_id"])
    return output


def _write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def _public_manifest_row(row: dict[str, Any], split: str) -> dict[str, Any]:
    return {
        "task_id": row["task_id"],
        "split": split,
        "level": row["level"],
        "attachment_type": row["attachment_type"],
        "has_attachment": row["has_attachment"],
        "question_sha256": row["question_sha256"],
        "answer_sha256": row["answer_sha256"],
        "attachment_sha256": row["attachment_sha256"],
        "row_sha256": row["row_sha256"],
    }


def build(args: argparse.Namespace) -> dict[str, Any]:
    if args.source_split.lower() != "validation":
        raise ValueError("This protocol only permits source_split=validation; private test data is out of scope.")
    snapshot_root = Path(args.snapshot_root).expanduser().resolve()
    output_root = Path(args.output_root).expanduser().resolve()
    if not snapshot_root.is_dir():
        raise NotADirectoryError(snapshot_root)
    if output_root.exists() and any(output_root.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty output directory: {output_root}")
    output_root.mkdir(parents=True, exist_ok=True)

    metadata_paths = _metadata_candidates(snapshot_root, args.source_split)
    rows, metadata_hashes = _normalise_rows(snapshot_root, metadata_paths, args.source_split, args.strict_attachments)
    targets = {"search": args.search_size, "select": args.select_size, "test": args.test_size}
    split_rows = _stratified_split(rows, targets, args.seed)

    # The records directory is intentionally private.  The public manifests
    # contain identifiers and hashes, never question/answer text.
    for split in SPLITS:
        private_rows = []
        for row in split_rows[split]:
            private_rows.append(
                {
                    "task_id": row["task_id"],
                    "question": row["question"],
                    "final_answer": row["final_answer"],
                    "level": row["level"],
                    "file_name": row["file_name"],
                    "file_path": row["file_path"],
                    "attachment_relpath": row["attachment_relpath"],
                    "attachment_type": row["attachment_type"],
                    "has_attachment": row["has_attachment"],
                    "attachment_path": row["attachment_path"],
                    "question_sha256": row["question_sha256"],
                    "answer_sha256": row["answer_sha256"],
                    "attachment_sha256": row["attachment_sha256"],
                    "row_sha256": row["row_sha256"],
                }
            )
        _write_jsonl(output_root / "records" / f"{split}.jsonl", private_rows)
        _write_jsonl(
            output_root / "manifests" / f"{split}.jsonl",
            (_public_manifest_row(row, split) for row in split_rows[split]),
        )

    counts = {
        split: {
            "total": len(split_rows[split]),
            "levels": dict(sorted(Counter(row["level"] for row in split_rows[split]).items())),
            "attachment_types": dict(sorted(Counter(row["attachment_type"] for row in split_rows[split]).items())),
        }
        for split in SPLITS
    }
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "dataset": "gaia",
        "source_repo": "gaia-benchmark/GAIA",
        "source_revision": args.source_revision,
        "source_split": args.source_split,
        "seed": args.seed,
        "targets": targets,
        "counts": counts,
        "stratification": ["Level", "attachment_type"],
        "model_input_exposes_level": False,
        "privacy": "private_only",
        "public_upload_policy": "manifests_only",
        "metadata_files": metadata_hashes,
        "snapshot_root_is_private": True,
        "records_contain_answers": True,
        "records_contain_attachment_paths": True,
        "notes": [
            "search/select/test are local protocol splits inside the official validation split",
            "test here is not the official GAIA private test and must be named gaia_local_test in reports",
            "do not upload records, attachments, metadata, or answers to a crawlable repository",
        ],
    }
    (output_root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output_root / "PRIVATE_ONLY.txt").write_text(
        "This directory contains GAIA questions, answers, and attachment paths. Keep it private.\n",
        encoding="utf-8",
    )
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot-root", required=True, help="Authorized local GAIA snapshot_download directory")
    parser.add_argument("--output-root", required=True, help="New private output directory")
    parser.add_argument("--source-split", default="validation")
    parser.add_argument("--source-revision", default=os.environ.get("GAIA_SOURCE_REVISION", "not-pinned"))
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--search-size", type=int, default=60)
    parser.add_argument("--select-size", type=int, default=30)
    parser.add_argument("--test-size", type=int, default=60)
    parser.add_argument(
        "--allow-missing-attachments",
        dest="strict_attachments",
        action="store_false",
        help="Only for debugging an incomplete mirror; never use for formal scores.",
    )
    parser.set_defaults(strict_attachments=True)
    args = parser.parse_args()
    try:
        manifest = build(args)
    except Exception as exc:  # concise CLI error without hiding traceback in logs
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({"output_root": str(Path(args.output_root).expanduser().resolve()), **manifest}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
