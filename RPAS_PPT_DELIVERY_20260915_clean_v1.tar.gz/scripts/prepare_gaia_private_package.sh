#!/usr/bin/env bash
set -euo pipefail

# Build a private, reproducible GAIA package from an already-authorized local
# snapshot.  This script deliberately does not download or upload GAIA data.
# Keep GAIA_SNAPSHOT and GAIA_PRIVATE_PACKAGE on an access-controlled node.

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "${SCRIPT_DIR}/.." && pwd)"

: "${GAIA_SNAPSHOT:?set GAIA_SNAPSHOT to the authorized local GAIA snapshot}"
: "${GAIA_PRIVATE_PACKAGE:?set GAIA_PRIVATE_PACKAGE to a new private output directory}"
: "${GAIA_SOURCE_REVISION:?set GAIA_SOURCE_REVISION to the pinned GAIA revision}"

SEARCH_SIZE="${GAIA_SEARCH_SIZE:-60}"
SELECT_SIZE="${GAIA_SELECT_SIZE:-30}"
TEST_SIZE="${GAIA_TEST_SIZE:-60}"
SEED="${GAIA_DATA_SEED:-2026}"

if [[ ! -d "${GAIA_SNAPSHOT}" ]]; then
  echo "ERROR: GAIA_SNAPSHOT is not a directory: ${GAIA_SNAPSHOT}" >&2
  exit 2
fi

if [[ -e "${GAIA_PRIVATE_PACKAGE}" ]]; then
  if [[ -d "${GAIA_PRIVATE_PACKAGE}" ]] && [[ -n "$(find "${GAIA_PRIVATE_PACKAGE}" -mindepth 1 -maxdepth 1 -print -quit)" ]]; then
    echo "ERROR: refusing to overwrite non-empty GAIA_PRIVATE_PACKAGE: ${GAIA_PRIVATE_PACKAGE}" >&2
    exit 2
  fi
fi

PYTHON_BIN="${EXPERIMENT_PYTHON:-python}"
"${PYTHON_BIN}" "${SCRIPT_DIR}/build_gaia_ppt_dataset.py" \
  --snapshot-root "${GAIA_SNAPSHOT}" \
  --output-root "${GAIA_PRIVATE_PACKAGE}" \
  --source-split validation \
  --source-revision "${GAIA_SOURCE_REVISION}" \
  --seed "${SEED}" \
  --search-size "${SEARCH_SIZE}" \
  --select-size "${SELECT_SIZE}" \
  --test-size "${TEST_SIZE}"

"${PYTHON_BIN}" "${SCRIPT_DIR}/audit_gaia_ppt_dataset.py" \
  --root "${GAIA_PRIVATE_PACKAGE}" \
  | tee "${GAIA_PRIVATE_PACKAGE}/audit_result.json"

echo
echo "GAIA private package ready: ${GAIA_PRIVATE_PACKAGE}"
echo "Keep the directory private; publish only protocol/schema/hash manifests."
