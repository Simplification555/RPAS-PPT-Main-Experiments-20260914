#!/usr/bin/env bash
# Resolve the runtime on a new compute node instead of assuming one user's
# home-directory layout. Source this file from the launcher or run it directly.
set -euo pipefail

_rpas_user_home="${RPAS_USER_HOME:-${HOME}}"
_rpas_has_module() {
  local python_bin="$1" module="$2"
  [[ -x "${python_bin}" ]] && "${python_bin}" -c "import ${module}" >/dev/null 2>&1
}

_rpas_add_conda_prefixes() {
  local conda_bin="$1"
  [[ -x "${conda_bin}" ]] || return 0
  while IFS= read -r prefix; do
    [[ -n "${prefix}" ]] && _rpas_qwen_candidates+=("${prefix}") && _rpas_gepa_candidates+=("${prefix}")
  done < <("${conda_bin}" env list 2>/dev/null | awk '/^\// {print $1}')
}

_rpas_choose_qwen() {
  local prefix python_bin
  for prefix in "${_rpas_qwen_candidates[@]}"; do
    python_bin="${prefix}/bin/python"
    if _rpas_has_module "${python_bin}" vllm && [[ -x "${prefix}/bin/vllm" ]]; then
      QWEN_ENV="${prefix}"
      QWEN_PYTHON="${python_bin}"
      VLLM_BIN="${prefix}/bin/vllm"
      return 0
    fi
  done
  if command -v vllm >/dev/null 2>&1 && _rpas_has_module "$(command -v python)" vllm; then
    QWEN_ENV=""
    QWEN_PYTHON="$(command -v python)"
    VLLM_BIN="$(command -v vllm)"
    return 0
  fi
  return 1
}

_rpas_choose_gepa() {
  local prefix python_bin
  for prefix in "${_rpas_gepa_candidates[@]}"; do
    python_bin="${prefix}/bin/python"
    if _rpas_has_module "${python_bin}" litellm; then
      GEPA_ENV="${prefix}"
      GEPA_PYTHON="${python_bin}"
      return 0
    fi
  done
  if _rpas_has_module "${QWEN_PYTHON}" litellm; then
    GEPA_ENV="${QWEN_ENV}"
    GEPA_PYTHON="${QWEN_PYTHON}"
    return 0
  fi
  return 1
}

_rpas_preflight_main() {
  : "${RPAS_REPO_ROOT:?set RPAS_REPO_ROOT to the checked-out RPAS repository}"
  local repo_root="${RPAS_REPO_ROOT}"
  _rpas_qwen_candidates=()
  _rpas_gepa_candidates=()
  [[ -n "${RPAS_QWEN_ENV:-}" ]] && _rpas_qwen_candidates+=("${RPAS_QWEN_ENV}")
  [[ -n "${RPAS_GEPA_ENV:-}" ]] && _rpas_gepa_candidates+=("${RPAS_GEPA_ENV}")
  for name in qwen35_vllm gepa_exp; do
    _rpas_qwen_candidates+=(
      "${_rpas_user_home}/miniconda3/envs/${name}"
      "${_rpas_user_home}/anaconda3/envs/${name}"
      "${_rpas_user_home}/mambaforge/envs/${name}"
      "${_rpas_user_home}/miniforge3/envs/${name}"
    )
    _rpas_gepa_candidates+=(
      "${_rpas_user_home}/miniconda3/envs/${name}"
      "${_rpas_user_home}/anaconda3/envs/${name}"
      "${_rpas_user_home}/mambaforge/envs/${name}"
      "${_rpas_user_home}/miniforge3/envs/${name}"
    )
  done
  if [[ -n "${CONDA_PREFIX:-}" ]]; then
    _rpas_qwen_candidates+=("${CONDA_PREFIX}")
    _rpas_gepa_candidates+=("${CONDA_PREFIX}")
  fi
  _rpas_add_conda_prefixes "${RPAS_CONDA_BIN:-$(command -v conda || true)}"

  if ! _rpas_choose_qwen; then
    cat >&2 <<'EOF'
ERROR: no usable Qwen/vLLM runtime was found.
Set RPAS_QWEN_ENV to an environment containing bin/python, importable vllm,
and bin/vllm, or load the node's CUDA/vLLM module before launching.
The current machine may not have the SCIR environment; do not install a
CUDA-specific vLLM wheel blindly on the login workstation.
EOF
    return 2
  fi
  if ! _rpas_choose_gepa; then
    cat >&2 <<'EOF'
ERROR: no experiment Python runtime was found.
Set RPAS_GEPA_ENV to an environment containing litellm and the RPAS external
baseline dependencies, or point it at the same environment as Qwen when it
contains both stacks.
EOF
    return 2
  fi

  EXPERIMENT_PYTHON="${RPAS_EXPERIMENT_PYTHON:-${GEPA_PYTHON}}"
  for required in torch transformers; do
    if ! _rpas_has_module "${QWEN_PYTHON}" "${required}"; then
      echo "ERROR: ${required} is missing from ${QWEN_PYTHON}" >&2
      return 2
    fi
  done
  for required in litellm pyarrow; do
    if ! _rpas_has_module "${EXPERIMENT_PYTHON}" "${required}"; then
      echo "ERROR: ${required} is missing from ${EXPERIMENT_PYTHON}" >&2
      return 2
    fi
  done
  command -v nvidia-smi >/dev/null 2>&1 || { echo "ERROR: nvidia-smi not found" >&2; return 2; }
  command -v curl >/dev/null 2>&1 || { echo "ERROR: curl not found" >&2; return 2; }
  [[ -d "${repo_root}" ]] || { echo "ERROR: repo root does not exist: ${repo_root}" >&2; return 2; }
  [[ -f "${RPAS_MODEL_PATH:-}" ]] || [[ -d "${RPAS_MODEL_PATH:-}" ]] || {
    echo "ERROR: RPAS_MODEL_PATH does not exist: ${RPAS_MODEL_PATH:-unset}" >&2
    return 2
  }
  [[ -d "${RPAS_MASBENCH_DATA_ROOT:-}" ]] || {
    echo "ERROR: RPAS_MASBENCH_DATA_ROOT does not exist: ${RPAS_MASBENCH_DATA_ROOT:-unset}" >&2
    return 2
  }
  [[ "${CUDA_VISIBLE_DEVICES:-0,1}" == "0,1" || "${CUDA_VISIBLE_DEVICES:-0,1}" == "0,1,"* ]] || {
    echo "ERROR: only logical GPU 0 and 1 are allowed; got ${CUDA_VISIBLE_DEVICES:-unset}" >&2
    return 2
  }

  export QWEN_ENV QWEN_PYTHON VLLM_BIN GEPA_ENV GEPA_PYTHON EXPERIMENT_PYTHON
  echo "[preflight] qwen_env=${QWEN_ENV:-PATH}"
  echo "[preflight] qwen_python=${QWEN_PYTHON}"
  echo "[preflight] vllm_bin=${VLLM_BIN}"
  echo "[preflight] experiment_env=${GEPA_ENV:-same-as-qwen}"
  echo "[preflight] experiment_python=${EXPERIMENT_PYTHON}"
  echo "[preflight] cuda_visible_devices=${CUDA_VISIBLE_DEVICES:-0,1}"
  echo "[preflight] runtime checks: PASS"
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  _rpas_preflight_main "$@"
else
  _rpas_preflight_main
fi
