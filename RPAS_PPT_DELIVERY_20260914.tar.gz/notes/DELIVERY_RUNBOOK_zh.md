# 主实验交付运行手册

## A. 目录和变量

```bash
export RPAS_REPO_ROOT=/mnt/cpfs/epic-user/niutianle-20260612/RPAS
export DATA_ROOT=$RPAS_REPO_ROOT/data/ppt_20260914
export MODEL_PATH=Qwen/Qwen3.5-9B
export CUDA_VISIBLE_DEVICES=0,1
```

不要把 Tinker key、SSH 密码、HF token 或其它 secret 写进脚本、配置、日志和 Git 历史。通过环境变量或计算节点的 secret store 注入。

## B. 数据边界

MASBench 五轴共用 official train/test 边界和同一 split seed，但每个轴单独生成 manifest。搜索和选择绝不读取 test。GAIA 只在用户有权限的本地 snapshot 上运行，公开仓库只保存 schema、manifest 和 hash。

## C. 变量控制

三种方法统一模型、prompt 外壳、解码参数、max tokens、答案协议、test ids 和计时口径；方法内部的 native search/workflow 保持原生，不把 RPAS 的候选预算硬塞给 AFlow/MaAS，也不把 AFlow/MaAS 搜索成本记为零。

主表报告：完整序列 accuracy、component accuracy、valid rate、error/protocol error、truncation、search/select/test calls、prompt/completion/total tokens、wall time、GPU-hours 和吞吐。

## D. 两卡调度

每张卡一个 9B 服务，先用 S0 smoke，再升到正式并发；客户端并发提高只改变排队速度，不能改变搜索预算、split、停止条件和样本过滤。脚本内置 GPU 越界检查，发现可见 GPU 不是 0、1 时直接退出。

## E. 验收

- 五个 MASBench 轴、三个方法均有独立 output/cache 目录；
- 三个方法使用相同 test manifest；
- 所有请求有 token、latency、finish reason、error、truncation 和 parser telemetry；
- GAIA 的附件读取、PDF/表格解析和工具错误均可追踪；
- 结果发布前通过 split leakage、manifest hash、可复现命令和 secret scan；
- 未完成 adapter 或缺少数据权限时，报告 blocker，不生成伪正式分数。
